/*************************************************/
/************ Author : Noor Ashraf         *******/
/************ Date : 29 August 2023        *******/
/************ version : 0.1                *******/
/************ file name : GPIO_CONFIG.h    *******/
/*************************************************/

# ifndef GPIO-INTERFACE_H
# define GPIO_INTERFACE_H












# endif